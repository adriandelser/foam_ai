import numpy as np
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import sys, pdb, string, random, traceback
sys.path.append('.')
#x = np.linspace(-3, 3, 256)
#y = np.linspace(-3, 3, 256)
#X, Y = np.meshgrid(x, y)
#Z = np.sinc(np.sqrt(X ** 2 + Y ** 2))

#fig = plt.figure()
#ax = fig.gca(projection = '3d')
#ax.plot_surface(X, Y, Z, cmap=cm.gray)
#plt.show()




#N = 50
#x = np.random.rand(N)
#y = np.random.rand(N)
#colors = np.random.rand(N)
#area = (30 * np.random.rand(N))**2  # 0 to 15 point radii

#plt.scatter(x, y, s=area, c=colors, alpha=0.5)
#plt.show()


from scipy.interpolate import LinearNDInterpolator

#import matplotlib.pyplot as plt

if 1==2:
	rng = np.random.default_rng()

	x = rng.random(10) - 0.5

	y = rng.random(10) - 0.5

	z = np.hypot(x, y)
	print(x,y,z)

	X = np.linspace(min(x), max(x))

	Y = np.linspace(min(y), max(y))

	X, Y = np.meshgrid(X, Y)  # 2D grid for interpolation

	interp = LinearNDInterpolator(list(zip(x, y)), z)

	Z = interp(X, Y)

	plt.pcolormesh(X, Y, Z, shading='auto')

	plt.plot(x, y, "ok", label="input point")

	plt.legend()

	plt.colorbar()

	plt.axis("equal")

	plt.show()

def dummy(array,meshCoords):
	#print("Python function running successfully")
	#print(type(array),len(array),'\n')
	#array = 2 * array
	#print(type(meshCoords),len(meshCoords),'\n', meshCoords[:,0])
	#print("Python function ended successfully")
	print("hi")
	print(np.array2string(array,separator = ', '))
	print(np.array2string(meshCoords,separator = ', '))
	
	array = array * 1
	x = meshCoords[: , 0]
	y = meshCoords[: , 1]
	X = np.linspace(min(x), max(x))
	Y = np.linspace(min(y), max(y))
	X, Y = np.meshgrid(x, y)
	#z = np.absolute(array)*10000
	z = array *10000
	z = z.T[0]
	#print(np.array2string(z,separator = ', '))
	print(x,y,z)
	print(len(x),len(y),len(z))
	#print(type(z))
	#print(X,Y)
	#s = np.random.rand(len(meshCoords))*200
	#fig = plt.figure()
	#ax = fig.gca(projection = '3d')
	#ax.plot_surface(X, Y, Z, cmap=cm.gray)

	#plt.show()
	#plt.scatter(x, y,s=Z,c=Z, cmap = "Spectral")
	#plt.show()
	
	interp = LinearNDInterpolator(list(zip(x, y)), z)

	Z = interp(X, Y)
	plt.figure()
	plt.pcolormesh(X, Y, Z)

	#plt.plot(x, y, "ok", label="input point")

	#plt.legend()

	plt.colorbar()

	plt.axis("equal")
	
	plt.show()
	return array
	
def python_func1(array, meshCoords):
	print("WASSSSUUUUUP")
	#dummy(array,meshCoords)
	print(array, meshCoords)
	return 1

def python_func(array, meshCoords):
	try:
		with open("out.txt", "w") as output:
			#print("Python function running successfully")
			#print(type(array),len(array),'\n')
			#array = 2 * array
			#print(type(meshCoords),len(meshCoords),'\n', meshCoords[:,0])
			#print("Python function ended successfully")
			print("hi",file=output)
			#print(np.array2string(array,separator = ', '))
			#print(np.array2string(meshCoords,separator = ', '))
			
		array = array * 1
		x = meshCoords[: , 0]
		y = meshCoords[: , 1]
		X = np.linspace(min(x), max(x))
		Y = np.linspace(min(y), max(y))
		X, Y = np.meshgrid(x, y)
		#z = np.absolute(array)*10000
		z = array *10000
		z = z.T[0]
		#print(np.array2string(z,separator = ', '))
		#print(x,y,z)
		print(len(x),len(y),len(z))
		#print(type(z))
		#print(X,Y)
		#s = np.random.rand(len(meshCoords))*200
		#fig = plt.figure()
		#ax = fig.gca(projection = '3d')
		#ax.plot_surface(X, Y, Z, cmap=cm.gray)

		#plt.show()
		#plt.scatter(x, y,s=Z,c=Z, cmap = "Spectral")
		#plt.show()
		print("after interpolation 1")
		interp = LinearNDInterpolator(list(zip(x, y)), z)
		print("after interpolation 2")
		Z = interp(X, Y)
		#plt.figure()
		print("after interpolation 3")
		#pdb.set_trace()
		plt.pcolormesh(X, Y, Z)
		print("after interpolation 4")

		fig, ax = plt.subplots()
		ax.plot(x, y, "ok", label="input point")
		plt.legend()

		#fig.colorbar()
		ax.grid()
		plt.axis("equal")
		fig.savefig("fig.png")
		#pdb.set_trace()
		#plt.imshow()
		print("after interpolation 5")
		#plt.show()
		print("after interpolation 6")
	except Exception as e:
		print(e)
		traceback.print_exc()
	return array

def random_char(y):
	return ''.join(random.choice(string.ascii_letters) for x in range(y))
	
#this is a test to write to a file
def test_func():
	#print("aslkfjd")
	
	# Data for plotting
	t = np.arange(0.0, 2.0, 0.01)
	print(t)
	s = 1 + np.sin(2 * np.pi * t)

	fig, ax = plt.subplots()
	ax.plot(t, s)

	ax.set(xlabel='time (s)', ylabel='voltage (mV)',
	       title='About as simple as it gets, folks')
	ax.grid()

	fig.savefig("test.png")
	#plt.show()
	
	with open("write_test.txt","w") as f:
		print("test5")
		mytext = random_char(5)
		f.write(mytext)
		f.write(str(s))
	return 5




