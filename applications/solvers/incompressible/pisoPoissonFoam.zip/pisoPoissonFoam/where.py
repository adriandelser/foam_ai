import numpy
print(numpy.__file__)

from distutils.sysconfig import get_python_inc
print(get_python_inc())
