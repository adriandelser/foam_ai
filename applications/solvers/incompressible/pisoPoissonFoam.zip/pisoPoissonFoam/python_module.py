import numpy as np
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import sys, pdb, string, random, traceback,torch
sys.path.append('.')
sys.path.append("/home/daep/a.del-ser/OpenFOAM/a.del-ser-9/flexinet/")
import simulationTesting
#x = np.linspace(-3, 3, 256)
#y = np.linspace(-3, 3, 256)
#X, Y = np.meshgrid(x, y)
#Z = np.sinc(np.sqrt(X ** 2 + Y ** 2))

#fig = plt.figure()
#ax = fig.gca(projection = '3d')
#ax.plot_surface(X, Y, Z, cmap=cm.gray)
#plt.show()




#N = 50
#x = np.random.rand(N)
#y = np.random.rand(N)
#colors = np.random.rand(N)
#area = (30 * np.random.rand(N))**2  # 0 to 15 point radii

#plt.scatter(x, y, s=area, c=colors, alpha=0.5)
#plt.show()


from scipy.interpolate import LinearNDInterpolator
from scipy import interpolate
#import matplotlib.pyplot as plt

#this is required because otherwise things go crazy when we sort the sets as not every coordinate is exactly equal

class Communication:
	def __init__(self,Uxarray=None, Uyarray=None, meshCoords=None, cellCoords=None):
        	#do whatever you want to do when initialising the class here
        	self.Uxarray = Uxarray
        	self.Uyarray = Uyarray
        	self.meshCoords = meshCoords
        	self.cellCoords = cellCoords
        	pass
        #define global variable decimals to round numbers like 1.99999999999999 to 2 due to computer precision limitations
	decimals = 8
	xTest, yTest = 0,0	
	cellCoords = 0
	cellsX = 0
	cellsY = 0
	def cellToFlags(self,cellCoords,u_interp, v_interp):
		#find cell spacing from cell coords
		#conserve only x and y coords
		cellCoords = np.delete(cellCoords,2,1)
		self.cellCoords = cellCoords
		#round the coordinates to a predefined number of decimal places to avoid errors
		cellCoords = np.around(cellCoords,decimals = self.decimals)
		print(f"cellCoords = {cellCoords}")
		#print(cellCoords,len(cellCoords))
		#list of x and y coordinates of existing cells in increasing order
		xSorted = sorted(set(cellCoords[:,0]))
		ySorted = sorted(set(cellCoords[:,1]))
		#print(len(xSorted),xSorted)
		x2 = xSorted[2]
		(x0,x1,xMax) = (xSorted[0],xSorted[1],xSorted[-1])
		(y0,y1,yMax) = (ySorted[0],ySorted[1],ySorted[-1])
		#print(x0,x1,x2,xMax)
		#get the spacing between cells if it is constant
		xSpacing = x1-x0
		ySpacing = y1-y0
		#print(xSpacing)
		#get the number of cells in the x and y directions
		cellsX = int((xMax-x0)/xSpacing + 1)
		self.cellsX = cellsX
		#print(cellsX)
		cellsY = int((yMax-y0)/ySpacing + 1)
		self.cellsY = cellsY
		
		#now make x and y coordinates for the flags array
		xx = np.around(np.linspace(xSpacing/2, xSpacing*(cellsX-1/2), cellsX),self.decimals)
		yy = np.around(np.linspace(ySpacing/2, ySpacing*(cellsY-1/2), cellsY),self.decimals)
		#print(xx)
		# next two lines convert cellcoords from np array to set of coordinate tuples so we can search them
		# and find which ones are obstacles 
		cellCoordsListOfTuples = [tuple(coord) for coord in cellCoords]
		cellCoordsSet = set(cellCoordsListOfTuples)
		#set to hold coordinates of obstacles
		obstacleCoordSet = set()
		obstacleCoordSetIndices = set()
		for i in xx:
			for j in yy:
				if (i,j) not in cellCoordsSet:
					#adds actual cell centre coordinates to the set
					obstacleCoordSet.add((i,j))
					#adds indices of those coordinates to a set
					x_index = np.where(xx==i)[0][0]
					y_index = np.where(yy==j)[0][0]
					obstacleCoordSetIndices.add((x_index,y_index))
					#print(f"u_interp shape = {u_interp.shape}")
					#print(f"v_interp shape = {v_interp.shape}")	
					#now we set the velocities in the obstacle region to 0			
					#u_interp first index is column (y_index), then row (x_index) (remember face centres instead of cell centres)
					u_interp[y_index+1, x_index+1], u_interp[y_index+1, x_index+2] = 0, 0
					v_interp[y_index+1, x_index+1], v_interp[y_index+2, x_index+1] = 0, 0
					
					#print(u_interp[int(j)])
					#print(x_index, y_index)
		#print(v_interp)
		# use this to find coordinates in array
		# np.where((cellCoords[:,0] == i) & (cellCoords[:,1]==j))
		#print(cellCoords,obstacleCoordSetIndices)
		flags = np.ones((cellsX, cellsY))
		for index in obstacleCoordSetIndices:
			flags[index[0]][index[1]] = 2
		#adding a 2 on all edges of flags as required by ekhi. 
		#print(f"shape of flags: {flags.shape}")
		#print(f"transpose of flags: {np.transpose(flags)}")
		flags = np.transpose(flags)
		flags = np.pad(flags, ((1, 1), (1, 1)), 'constant', constant_values = (2))
		#Extra brackets are also introduced as per ekhi
		flags = np.expand_dims(flags, axis=0)
		#need to join U and V arrays like Ekhi does
		U_in = np.stack((u_interp,v_interp))
		print(f"U_in is {U_in}")
		#print(flags)
		flags = torch.from_numpy(flags).float()
		U_in = torch.from_numpy(U_in).float()
		#u_interp = torch.from_numpy(u_interp).float()
		#v_interp = torch.from_numpy(v_interp).float()
		#print(flags,U_in)
		p_out, u_out = simulationTesting.runNetwork(U_in,flags)
		print(f"p_out = {p_out}")
		self.py_to_foam_velocity(u_out)
		
	def py_to_foam_velocity(self, u_out):
		#convert velocity from neural network format back to openfoam format
		#effectively we need to make sure that the output pressure and velocity arrays are the same as those sent in by openfoam
		
		#shape of u_out is (timesteps,number of velocity fields (ie u and v), dimZ, dimY, dimX)
		#need to use .detach() if array was created on GPU
		#we extract the first (only) timestep, the u field and its values in x and y
		u_field = u_out[0,0,0].detach().numpy()
		v_field = u_out[0,1,0].detach().numpy()
		
		#we now get rid of the useless padding from the network output
		u_field = u_field[1:-1,1:]
		v_field = v_field[1:,1:-1]
		print(v_field.shape)
		print(f"u_field = {u_field}")
		#create interpolation functions for u and v
		fx = self._reverseInterpolate(u_field,"u")
		fy = self._reverseInterpolate(v_field,"v")
		xNew = self.cellCoords[:,0]
		yNew = self.cellCoords[:,1]
		zNew = fx(xNew, yNew)
		print(u_field, zNew)
		return None
		
	def _reverseInterpolate(self,field, field_name:str):
		#interpolate given field (u_field or v_field) to return function that can be used to calculate cell centre values
		if field_name == "u":
			x = np.linspace(0, 10, self.cellsX + 1)
			y = np.linspace(0.5, 5.5, self.cellsY)
			#xx, yy = np.meshgrid(x, y)
		elif field_name == "v":
			x = np.linspace(0.5, 9.5, self.cellsX)
			y = np.linspace(0, 6, self.cellsY + 1)
			#xx, yy = np.meshgrid(x, y)
		else:
			raise TypeError("field_name must be 'u' or 'v'")
			
		z = field
		f = interpolate.interp2d(x, y, z, kind='cubic')
		return f	
		
	def python_func1(self,Uxarray, Uyarray, meshCoords, cellCoords):
		#meshcoords is face centres and cellCoords is cell centres
		try:
			#keep only first two columns since we are in 2D
			meshCoords = np.delete(meshCoords,2,1)
			#dummy(array,meshCoords)
			#print(Uxarray, len(Uxarray),type(Uxarray), "\n", meshCoords,len(meshCoords),type(meshCoords))
			#Px is x
			Px = meshCoords[:,0]
			Py = meshCoords[:,1]
			#print(f"meshCoords = {meshCoords}")
			#print(Uxarray[0])

			plt.figure(1)
			plt.quiver(Px, Py, Uxarray, Uyarray)
			plt.savefig("rawVelocities.png")
			#now generate nice cartesian grid for CNN to operate on
			#these are for plotting purposes only
			cells_x = 10
			cells_y = 6
			xx = np.linspace(0, 10, cells_x+1)
			yy = np.linspace(0.5, 5.5, cells_y)
			#first for U at face centres with normal (1,0)
			xxU = np.linspace(0, 10, cells_x+1)
			yyU = np.linspace(0.5, 5.5, cells_y)
			
			#temporarily define these test arrays to test reverse interpolation back to openfoam format
			self.xTest, self.yTest = xxU, yyU
			
			#now for V at face centres with normal (0,1)
			xxV = np.linspace(0.5, 9.5, cells_x)
			yyV = np.linspace(0, 6, cells_y+1)
			xx, yy = np.meshgrid(xx, yy)
			xxU, yyU = np.meshgrid(xxU, yyU)
			xxV, yyV = np.meshgrid(xxV, yyV)
			#print("XX",xx,type(xx),xx.shape,"\n","YY",yy)
			#vstack stacks two arrays verctically
			#points = np.transpose(np.vstack((Px, Py)))
			#print(f"points = {points}")
			#here meshCoords has replaced points
			#interpolate from mesh face centres to cartesian grids
			print(f"Uxarray = {Uxarray}")
			print(f"Uxarray shape is {Uxarray.shape}")
			print(f"meshCoords is {meshCoords}")
			print(f"xx = {xx}")
			print(f"yy = {yy}")
			u_interpPlot = interpolate.griddata(meshCoords, Uxarray, (xx, yy), method='linear')
			v_interpPlot = interpolate.griddata(meshCoords, Uyarray, (xx, yy), method='linear')		
			u_interp = interpolate.griddata(meshCoords, Uxarray, (xxU, yyU), method='linear')
			v_interp = interpolate.griddata(meshCoords, Uyarray, (xxV, yyV), method='linear')
			#get nearest interpolation to fill in nan due to interpolation
			u_interpNearestPlot = interpolate.griddata(meshCoords, Uxarray, (xx, yy), method='nearest')
			v_interpNearestPlot = interpolate.griddata(meshCoords, Uyarray, (xx, yy), method='nearest')		
			u_interpNearest = interpolate.griddata(meshCoords, Uxarray, (xxU, yyU), method='nearest')
			v_interpNearest = interpolate.griddata(meshCoords, Uyarray, (xxV, yyV), method='nearest')
			#now replace nan values due to linear interpolation with values from nearest interpolation
			u_interpPlot[np.isnan(u_interpPlot)] = u_interpNearestPlot[np.isnan(u_interpPlot)]
			v_interpPlot[np.isnan(v_interpPlot)] = v_interpNearestPlot[np.isnan(v_interpPlot)]		
			u_interp[np.isnan(u_interp)] = u_interpNearest[np.isnan(u_interp)]
			v_interp[np.isnan(v_interp)] = v_interpNearest[np.isnan(v_interp)]
			#now we squeeze them so they are the same as in Ekhi's network
			print(f"u interp is {u_interp}\n",f"v_interp is {v_interp}")
			u_interpPlot = np.squeeze(u_interpPlot)
			v_interpPlot = np.squeeze(v_interpPlot)
			u_interp = np.squeeze(u_interp)
			v_interp = np.squeeze(v_interp)
			plt.figure(2)
			plt.quiver(xx, yy, u_interpPlot, v_interpPlot)
			#plt.show()
			#call cellstoflags

			plt.savefig("InterpolatedVelocities.png")
			
			#now we need to pad the velocity arrays with stuff because ekhi did that
			#need to add extra layer to the left for u_interp as well as above and below
			u_interp = np.pad(u_interp, ((1, 1), (1, 0)), 'constant', constant_values = (1))
			#need to add extra layer to the left and right for v_interp as well as below
			v_interp = np.pad(v_interp, ((1, 0), (1, 1)), 'constant', constant_values = (0))		
			print(f"u interp is {u_interp}\n",f"v_interp is {v_interp}")
			self.cellToFlags(cellCoords,u_interp,v_interp)
			#and now we can unpad it to send it back to openFoam
			u_interp = u_interp[1:-1,1:-1]
			#print(u_interp)
			#print(meshCoords.shape)
		except Exception as e:
			print(e)
			traceback.print_exc()
		
		return 1
#python_func(2)
#print(python_func(2))

def python_func(self,array, meshCoords):
	try:
		with open("out.txt", "w") as output:
			#print("Python function running successfully")
			#print(type(array),len(array),'\n')
			#array = 2 * array
			#print(type(meshCoords),len(meshCoords),'\n', meshCoords[:,0])
			#print("Python function ended successfully")
			print("hi",file=output)
			#print(np.array2string(array,separator = ', '))
			#print(np.array2string(meshCoords,separator = ', '))
			
		array = array * 1
		x = meshCoords[: , 0]
		y = meshCoords[: , 1]
		X = np.linspace(min(x), max(x))
		Y = np.linspace(min(y), max(y))
		X, Y = np.meshgrid(x, y)
		#z = np.absolute(array)*10000
		z = array *10000
		z = z.T[0]
		#print(np.array2string(z,separator = ', '))
		#print(x,y,z)
		print(len(x),len(y),len(z))
		#print(type(z))
		#print(X,Y)
		#s = np.random.rand(len(meshCoords))*200
		#fig = plt.figure()
		#ax = fig.gca(projection = '3d')
		#ax.plot_surface(X, Y, Z, cmap=cm.gray)

		#plt.show()
		#plt.scatter(x, y,s=Z,c=Z, cmap = "Spectral")
		#plt.show()
		print("after interpolation 1")
		interp = LinearNDInterpolator(list(zip(x, y)), z)
		print("after interpolation 2")
		Z = interp(X, Y)
		#plt.figure()
		print("after interpolation 3")
		#pdb.set_trace()
		plt.pcolormesh(X, Y, Z)
		print("after interpolation 4")

		fig, ax = plt.subplots()
		ax.plot(x, y, "ok", label="input point")
		plt.legend()

		#fig.colorbar()
		ax.grid()
		plt.axis("equal")
		fig.savefig("fig.png")
		#pdb.set_trace()
		#plt.imshow()
		print("after interpolation 5")
		#plt.show()
		print("after interpolation 6")
	except Exception as e:
		print(e)
		traceback.print_exc()
	return array

def random_char(self,y):
	return ''.join(random.choice(string.ascii_letters) for x in range(y))
	
#this is a test to write to a file
def test_func(self):
	print("worked")

